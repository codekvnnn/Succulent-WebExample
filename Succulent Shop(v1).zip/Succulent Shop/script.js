function shoppingCartClick(){
    alert("Your Cart is empty!");
}
function change_featured_img(e,id){
    document.getElementById(id).src = e.src
}
function _remove(id){
    document.getElementById(id).remove()
}
function IAcceptButton(){
    document.getElementById("bottomWindowAlert").hidden=true;
    // console.log("IAcceptButton");
}